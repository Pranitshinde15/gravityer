const nums = [2, 7, 11, 15];
const target = 9;

function findIndex(nums, target) {
  const array = {};

  for (let i = 0; i < nums.length; i++) {
    const num = target - nums[i];

    if (array[num] !== undefined) {
      return [array[num], i];
    }

    array[nums[i]] = i;
  }
  return [];
}

console.log(findIndex(nums, target));
